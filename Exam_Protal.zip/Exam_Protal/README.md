# Exam_Protal
In exam portal we are doing things related to exam like get syllabus, seating arrangement, schedule, etc.

First need to run "npm install" command to install node modules

Second create uploads folder in project folder.

In public folder we have html and css files. 
